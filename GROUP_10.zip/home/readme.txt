Test Users-
id	first_name	last_name	email	password	age	gender	street_address	lattitude	longitude	traffic_source	created_at
Curtis	Thompson	curtisthompson@example.org	CurtisThompson	12	M	118 Blair Shoal	34.85181443	136.5087133	Organic	2019-01-10 09:24:00
Dustin	Cox	dustincox@example.net	DustinCox	45	M	0864 Matthew Springs Apt. 386	-9.945567619	-67.83560991	Search	2019-05-21 12:54:00
Robert	Lee	robertlee@example.com	RobertLee	62	M	68530 Dean Greens Apt. 724	-9.945567619	-67.83560991	Search	2022-03-20 06:54:00
Michelle	Rowe	michellerowe@example.com	MichelleRowe	68	F	70000 Ronald Glens	-9.945567619	-67.83560991	Search	2020-06-11 09:43:00

Admin User-
ee3200313@iitd.ac.in  qwertyuiop