from flask import Flask,session
# from flask_sqlalchemy import SQLAlchemy
# from flask_bcrypt import Bcrypt
# from flask_mail import Mail
from flask_session import Session
import os


app=Flask(__name__)

app.config['SECRET_KEY']='91c67d9c1ce1aa0b2684183b622576ae'
# app.config['SQLALCHEMY_DATABASE_URI']='postgresql://group_10:FCHf9w6CsfukyAm@10.17.51.34/group_10'
# db = SQLAlchemy(app)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
app.session_cookie_name = 'airy_session'
Session(app)

# # bcrypt= Bcrypt(app)
# login_manager=LoginManager(app)
# login_manager.login_view='login'
# app.app_context().push()

# app.config['MAIL_SERVER']='smtp.gmail.com'
# app.config['MAIL_PORT']=587
# app.config['MAIL_USE_TLS']=True
# app.config['MAIL_USERNAME']=os.environ.get('EMAIL_USER')
# app.config['MAIL_PASSWORD']=os.environ.get('EMAIL_PASS')
# mail=Mail(app)

from home import routes