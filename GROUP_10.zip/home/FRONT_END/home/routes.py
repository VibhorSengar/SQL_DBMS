from flask import render_template,flash,redirect,url_for,request
from home.home import app
from home.forms import LoginForm,RegistrationForm,UpdateAccountForm
import psycopg2
from home.home import session
import math
from flask_paginate import Pagination



def get_db_connection():
    conn = psycopg2.connect(
    host= '10.17.51.34',
    database= 'group_10',
    user= 'group_10',
    password= 'FCHf9w6CsfukyAm'
    )
    return conn


# session['current_user']=None

@app.route("/")
def home():
    return redirect(url_for('products',page=1))

@app.route("/admin",methods=['GET', 'POST'])
def adminhome():
    if session.get('current_user') and session['current_user'][3]=="ee3200313@iitd.ac.in":
        if request.method=='POST':
            if(request.form.get('id')=="1"):
                if(request.form.get('orderid')):
                    orderid=request.form.get('orderid')
                    conn=get_db_connection()
                    curr=conn.cursor()
                    curr.execute("select * from orders where order_id="+orderid)
                    order=curr.fetchone()
                    if not order:
                        flash('Order: #'+orderid+' does not exist.','danger')
                    else:
                        # print("check1")
                        if(request.form.get('ship')):
                            if order[2]!="Processing":
                                flash('Order: #'+orderid+' is already '+str(order[2])+'.','danger')
                            else:
                                curr.execute("update order_items  set status='Shipped', shipped_at=current_date where order_id="+str(orderid)+" and status= 'Processing'")
                                conn.commit()
                                curr.execute("update orders  set status='Shipped', shipped_at=current_date where order_id="+str(orderid)+" and status= 'Processing'")
                                conn.commit()
                                flash('Order: #'+orderid+'has been shipped.','success')
                        elif(request.form.get('deliver')):
                            if order[2]=="Processing":
                                flash('Order: #'+orderid+' has not shipped yet.','danger')
                            elif order[2]!="Shipped":
                                flash('Order: #'+orderid+' is already '+str(order[2])+'.','danger')
                            else:
                                curr.execute("update order_items  set status='Complete', delivered_at=current_date where order_id="+str(orderid)+" and status= 'Shipped'")
                                conn.commit()
                                curr.execute("update orders  set status='Complete', delivered_at=current_date where order_id="+str(orderid)+" and status= 'Shipped'")
                                conn.commit()
                                flash('Order: #'+orderid+'has been delivered.','success')
                else:
                    flash('Invalid order!','danger')

            elif (request.form.get('id')=="2"):
                if(request.form.get('productid') and request.form.get('qty')):
                    productid=request.form.get('productid')
                    conn=get_db_connection()
                    curr=conn.cursor()
                    curr.execute("select * from products where id="+productid)
                    product=curr.fetchone()
                    if not product:
                        flash('Product: #'+productid+' does not exist.','danger')
                    else:
                        qty=request.form.get('qty')
                        curr.execute("select max(id) from inventory_items")
                        max_inv_id=curr.fetchone()
                        max_inv=int(max_inv_id[0])
                        for x in range(int(qty)):
                            max_inv=max_inv+1
                            curr.execute(" INSERT into inventory_items (id, product_id, created_at, cost)\
                            values ("+str(max_inv)+", "+productid+", current_date, "+str(product[1])+") ")

                        curr.execute(" update products set stock=stock+"+qty+" where id="+productid)
                        conn.commit()
                        flash('Product: #'+productid+' added successfully.','success')
                else:
                    flash('Invalid input','danger')


            elif (request.form.get('id')=="3"):
                query="WITH a AS ( SELECT DISTINCT products.id AS product_id, products.name AS product_name, ROUND(products.retail_price::decimal,2) AS retail_price,\
                ROUND(products.cost::decimal,2) AS cost, ROUND((SUM(products.retail_price)-SUM(products.cost))::decimal,2) AS profit, 'most profitable' AS product_conclusion\
                FROM products INNER JOIN inventory_items ON products.id=inventory_items.product_id INNER JOIN order_items ON inventory_items.id = order_items.inventory_item_id\
                INNER JOIN orders ON order_items.order_id = orders.order_id GROUP BY 1,2,3,4 ORDER BY 5 DESC LIMIT 5 ), b AS ( SELECT DISTINCT products.id AS product_id,\
                products.name AS product_name, ROUND(products.retail_price::decimal,2) AS retail_price, ROUND(products.cost::decimal,2) AS cost, ROUND((SUM(products.retail_price)-SUM(products.cost))::decimal,2) AS profit,\
                'least profitable' AS product_conclusion FROM products INNER JOIN inventory_items ON products.id=inventory_items.product_id INNER JOIN order_items ON inventory_items.id = order_items.inventory_item_id\
                INNER JOIN orders ON order_items.order_id = orders.order_id GROUP BY 1,2,3,4 ORDER BY 5 LIMIT 5 ) SELECT *, RANK() OVER (ORDER BY a.profit DESC) ranking FROM a\
                UNION ALL SELECT *, RANK() OVER (ORDER BY b.profit) ranking FROM b ORDER BY 6 DESC, 7;"
                conn=get_db_connection()
                curr=conn.cursor()
                curr.execute(query)
                records=curr.fetchall()
                colnames = [desc[0] for desc in curr.description]
                return render_template('table.html' , records = records , colnames = colnames , current_user=session.get('current_user'))

            
            else:
                if (request.form.get('date1') and request.form.get('date2')):
                    date1=request.form.get('date1')
                    date2=request.form.get('date2')
                    if(date1<=date2):
                        query=""
                        if(request.form.get('id')=="4"):
                            query="SELECT DATE_TRUNC('month', orders.created_at::DATE) AS month_year, orders.status AS order_status, COUNT(DISTINCT users.id) AS total_of_unique_users, COUNT(orders.order_id) AS total_orders, ROUND(SUM(order_items.sale_price)::decimal, 2) AS total_sale_price FROM users INNER JOIN orders ON users.id = orders.user_id INNER JOIN Order_items ON orders.order_id = order_items.order_id WHERE orders.created_at::date BETWEEN '"+date1+"'::DATE AND '"+date2+"'::DATE GROUP BY 1, 2 ORDER BY 1"
                        elif(request.form.get('id')=="5"):
                            query="SELECT DATE_TRUNC('month',DATE(orders.created_at)) AS month_year, COUNT(orders.order_id) AS frequencies, ROUND((SUM(order_items.sale_price)/COUNT(orders.order_id))::decimal,2) AS AOV, COUNT(DISTINCT users.id) AS unique_buyers FROM users LEFT JOIN orders ON users.id = orders.user_id LEFT JOIN order_items ON users.id = order_items.order_id WHERE DATE(orders.created_at)::date BETWEEN '"+date1+"' AND '"+date2+"' AND LOWER(orders.status) = 'complete' GROUP BY 1 ORDER BY 1"
                        elif(request.form.get('id')=="6"):
                            query="WITH users AS ( SELECT * FROM users), orders AS ( SELECT * FROM orders WHERE status = 'Returned' AND DATE(returned_at) BETWEEN '"+date1+"'\
                            AND '"+date2+"'), main AS ( SELECT DISTINCT users.id AS user_id, users.email AS user_email, users.first_name AS user_first_name, users.last_name AS user_last_name\
                            FROM users INNER JOIN orders ON users.id = orders.user_id) SELECT * FROM main ORDER BY 3"
                        elif(request.form.get('id')=="7"):
                            query="WITH monthly_profits AS ( SELECT DATE_TRUNC('month', DATE(created_at)) AS month, products.category, SUM(products.retail_price) - SUM(products.cost) AS profit\
                            FROM inventory_items INNER JOIN products ON inventory_items.product_id = products.id WHERE DATE(created_at) BETWEEN '"+date1+"' AND '"+date2+"' GROUP BY\
                            1, 2 ), monthly_profits_with_previous AS ( SELECT month, category, profit, LAG(profit) OVER (PARTITION BY category ORDER BY month) AS previous_profit\
                            FROM monthly_profits) SELECT month, category AS product_category, CAST(ROUND(profit) AS int) AS profit, CAST(ROUND(previous_profit) AS int) AS previous_profit,\
                            CONCAT(CAST(ROUND(((profit - previous_profit) / previous_profit) * 100) AS int), '%') AS growth FROM monthly_profits_with_previous ORDER BY product_category,month"
                        elif(request.form.get('id')=="8"):
                            query="WITH cohort AS ( SELECT orders.user_id, MIN(DATE_TRUNC('month', order_items.created_at::date)) AS cohort_month FROM order_items INNER JOIN orders ON order_items.order_id=orders.order_id\
                            WHERE DATE_TRUNC('month', order_items.created_at::date) BETWEEN '"+date1+"' AND '"+date2+"' AND order_items.status = 'Complete' GROUP BY 1 ), order_cohort AS (\
                            SELECT orders.user_id AS user_id, EXTRACT(MONTH FROM age(DATE_TRUNC('month',orderss.created_at::date), cohort.cohort_month::date)) AS month_number FROM order_items AS orderss\
                            INNER JOIN orders ON orders.order_id=orderss.order_id LEFT JOIN cohort ON orders.user_id = cohort.user_id WHERE DATE_TRUNC('month', orderss.created_at::date) BETWEEN '"+date1+"' AND '"+date2+"'\
                            AND orderss.status = 'Complete'), cohort_orders AS ( SELECT cohort_month, COUNT(DISTINCT user_id) AS cohort_size FROM cohort GROUP BY 1), monthly_orders AS ( SELECT\
                            cohort.cohort_month, order_cohort.month_number, COUNT(DISTINCT order_cohort.user_id) AS num_orders FROM order_cohort LEFT JOIN cohort ON order_cohort.user_id = cohort.user_id\
                            GROUP BY 1, 2), percentage_orders AS ( SELECT monthly_orders.cohort_month, cohort_orders.cohort_size, monthly_orders.month_number, monthly_orders.num_orders,\
                            CONCAT(ROUND((monthly_orders.num_orders::decimal / cohort_orders.cohort_size::decimal) * 100, 2), '%') AS percentage FROM monthly_orders JOIN cohort_orders ON monthly_orders.cohort_month = cohort_orders.cohort_month)\
                            SELECT cohort_month, cohort_size, month_number, num_orders, percentage FROM percentage_orders WHERE cohort_month IS NOT NULL ORDER BY 1, 3"
                        conn=get_db_connection()
                        curr=conn.cursor()
                        curr.execute(query)
                        records=curr.fetchall()
                        colnames = [desc[0] for desc in curr.description]
                        return render_template('table.html' , records = records , colnames = colnames , current_user=session.get('current_user'))
                    else:
                        flash('From date must be earlier than To date', 'danger')
                else:
                    flash('Invalid date', 'danger')


        return render_template('adminhome.html',current_user=session.get('current_user'))
        
    return redirect(url_for('adminlogin'))

    


@app.route("/products",methods=['GET','POST'])
@app.route("/products/page:<page>",methods=['GET','POST'])
@app.route("/products/page:<page>/brand:<brand>",methods=['GET','POST'])
@app.route("/products/brand:<brand>",methods=['GET','POST'])
@app.route("/products/page:<page>/category:<category>",methods=['GET','POST'])
@app.route("/products/category:<category>",methods=['GET','POST'])
@app.route("/products/brand:<brand>/category:<category>",methods=['GET','POST'])
@app.route("/products/page:<page>/brand:<brand>/category:<category>",methods=['GET','POST'])
@app.route("/products/page:<page>/department:<department>",methods=['GET','POST'])
@app.route("/products/department:<department>",methods=['GET','POST'])
@app.route("/products/page:<page>/brand:<brand>/department:<department>",methods=['GET','POST'])
@app.route("/products/brand:<brand>/department:<department>",methods=['GET','POST'])
@app.route("/products/page:<page>/category:<category>/department:<department>",methods=['GET','POST'])
@app.route("/products/category:<category>/department:<department>",methods=['GET','POST'])
@app.route("/products/page:<page>/brand:<brand>/category:<category>/department:<department>",methods=['GET','POST'])
@app.route("/products/page:<page>/category:<category>/department:<department>",methods=['GET','POST'])
@app.route("/products/page:<page>/brand:<brand>/department:<department>",methods=['GET','POST'])
@app.route("/products/page:<page>/order:<order>",methods=['GET','POST'])
@app.route("/products/page:<page>/brand:<brand>/order:<order>",methods=['GET','POST'])
@app.route("/products/page:<page>/category:<category>/order:<order>",methods=['GET','POST'])
@app.route("/products/page:<page>/brand:<brand>/category:<category>/order:<order>",methods=['GET','POST'])
@app.route("/products/page:<page>/department:<department>/order:<order>",methods=['GET','POST'])
@app.route("/products/page:<page>/brand:<brand>/department:<department>/order:<order>",methods=['GET','POST'])
@app.route("/products/page:<page>/category:<category>/department:<department>/order:<order>",methods=['GET','POST'])
@app.route("/products/page:<page>/brand:<brand>/category:<category>/department:<department>/order:<order>",methods=['GET','POST'])
@app.route("/products/order:<order>",methods=['GET','POST'])
@app.route("/products/brand:<brand>//order:<order>",methods=['GET','POST'])
@app.route("/products/category:<category>/order:<order>",methods=['GET','POST'])
@app.route("/products/brand:<brand>/category:<category>/order:<order>",methods=['GET','POST'])
@app.route("/products/department:<department>/order:<order>",methods=['GET','POST'])
@app.route("/products/brand:<brand>/department:<department>/order:<order>",methods=['GET','POST'])
@app.route("/products/category:<category>/department:<department>/order:<order>",methods=['GET','POST'])
@app.route("/products/brand:<brand>/category:<category>/department:<department>/order:<order>",methods=['GET','POST'])
def products(page=1,brand=None,category=None,department=None,order=None):
    conn=get_db_connection()
    curr=conn.cursor()
    print('in products')
    page=int(page)
    per_page=10
    if request.method=='POST':
        print(request.form.get('search'),request.form.get('add-to-cart'))
        if request.form.get('search'):
            print('in search')
            brand=request.form.get('brand')
            if(brand==''):
                brand=None
            category=request.form.get('category')
            if(category==''):
                category=None
            page=request.form.get('page')
            if(page==''):
                page=1
            else:
                page=int(page)
            department=request.form.get('department')
            price=request.form.get('sort-by')
        
            if department=='none':
                department=None
            if(request.form.get('sort-by')=='none'):
                price=None
            elif(request.form.get('sort-by')=='Price: High to Low'):
                price='DESC'
            elif(request.form.get('sort-by')=='Price: Low to High'):
                price='ASC'
            return redirect(url_for('products',brand=brand,category=category,department=department,order=price,page=page))
        if request.form.get('add_to_cart'):
            if not session.get('current_user'):
                flash('Please login to add products to cart','danger')
                return redirect(url_for('login'))
            else:
                if(request.form.get('quantity')):
                    product_id=request.form.get('product_id')
                    quantity=request.form.get('quantity')
                    if product_id in session.get('cart'):
                        session['cart'][product_id]+=int(quantity)
                    else:
                        session['cart'][product_id]=int(quantity)
                    flash('Product added to cart','success')
                else:
                    flash('Invalid input','danger')
            return redirect(url_for('products',brand=brand,category=category,department=department,order=order,page=page))
        
    if order:
        if department:
            if brand and category:
                flash('Showing products of brand '+brand+' and category '+category+' in department '+department+' ordered by '+order+ 'price','success')
                curr.execute("SELECT * FROM products WHERE brand=%s AND category=%s AND department=%s ORDER BY retail_price "+order+ "  ",[brand, category, department  ])
            elif brand:
                flash('Showing products of brand '+brand+' in department '+department+' ordered by '+order+ 'price','success')
                curr.execute("SELECT * FROM products WHERE brand=%s AND department=%s ORDER BY retail_price "+order+ "  ",[brand, department  ])
            elif category:
                flash('Showing products of category '+category+' in department '+department+' ordered by '+order+ ' price','success')
                curr.execute("SELECT * FROM products WHERE category=%s AND department=%s ORDER BY retail_price "+order+ "  ",[category, department  ])
            else:
                flash('Showing products in department '+department+' ordered by '+order+ ' price','success')
                curr.execute("fSELECT * FROM products WHERE department=%s ORDER BY retail_price "+order+ "  ",[department  ])
        else:
            if brand and category:
                flash('Showing products of brand '+brand+' and category '+category+' ordered by '+order+ ' price','success')
                curr.execute("SELECT * FROM products WHERE brand=%s AND category=%s ORDER BY retail_price "+order+"  ",[brand, category  ])
            elif brand:
                flash('Showing products of brand '+brand+' ordered by '+order+ ' price','success')
                curr.execute("SELECT * FROM products WHERE brand=%s ORDER BY retail_price "+order+"  ",[brand  ])
            elif category:
                flash('Showing products of category '+category+' ordered by '+order+ ' price','success')
                curr.execute("SELECT * FROM products WHERE category=%s ORDER BY retail_price "+order+"  ",[category  ])
            else:
                flash('Showing products ordered by '+order+ ' price','success')
                curr.execute("SELECT * FROM products ORDER BY retail_price "+order+"  ")
    else:
        if department:
            if brand and category:
                flash('Showing products of brand '+brand+' and category '+category+' in department '+department,'success')
                curr.execute("SELECT * FROM products WHERE brand=%s AND category=%s AND department=%s  ",[brand, category, department  ])
            elif brand:
                flash('Showing products of brand '+brand+' in department '+department,'success')
                curr.execute("SELECT * FROM products WHERE brand=%s AND department=%s  ",[brand, department  ])
            elif category:
                flash('Showing products of category '+category+' in department '+department,'success')
                curr.execute("SELECT * FROM products WHERE category=%s AND department=%s  ",[category, department  ])
            else:
                flash('Showing products in department '+department,'success')
                curr.execute("SELECT * FROM products WHERE department=%s  ",[department  ])
        else:
            if brand and category:
                flash('Showing products of brand '+brand+' and category '+category,'success')
                curr.execute("SELECT * FROM products WHERE brand=%s AND category=%s  ",[brand, category  ])
            elif brand:
                flash('Showing products of brand '+brand,'success')
                curr.execute("SELECT * FROM products WHERE brand=%s  ",[brand  ])
            elif category:
                flash('Showing products of category '+category,'success')
                curr.execute("SELECT * FROM products WHERE category=%s  ",[category  ])
            else:
                curr.execute("SELECT * FROM products  ")

    products=curr.fetchall()
    total_pages=math.ceil(len(products)/per_page)
    pagination=Pagination(page=page,per_page=per_page,total=len(products), css_framework="bootsrap4")
    start=(page-1)*per_page
    end=start+per_page
    products=products[start:end]
    print(page)
    return render_template('products.html',title='Products',products=products, pagination=pagination, page=page, total_pages=total_pages ,current_user=session.get('current_user'),brand=brand,category=category,department=department,order=order)


@app.route("/adminlogin",methods=['GET','POST'])
def adminlogin():
    if session.get('current_user') and session['current_user'][3]=="ee3200313@iitd.ac.in":
        return redirect(url_for('adminhome'))
    conn=get_db_connection()
    curr=conn.cursor()
    form=LoginForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            if form.email.data=="ee3200313@iitd.ac.in":
                curr.execute("SELECT * FROM users WHERE email=%s",[form.email.data])
                user=curr.fetchone()
                if user and user[4]==form.password.data:
                    session['current_user']=user
                    session['cart']={}
                    flash('You have been logged in!','success')
                    return  redirect(url_for('adminhome'))
                else:
                    flash('Login Unsuccessful. Please check email and password','danger')
                    return  redirect(url_for('adminlogin'))    
            else :
                flash('Login Unsuccessful. Please check email and password','danger')
                return  redirect(url_for('adminlogin'))  
    return render_template('adminlogin.html',title='AdminLogin',form=form,current_user=session.get('current_user'))

@app.route("/login",methods=['GET','POST'])
def login():
    if session.get('current_user'):
        return redirect(url_for('home'))
    conn=get_db_connection()
    curr=conn.cursor()
    form=LoginForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            curr.execute("SELECT * FROM users WHERE email=%s",[form.email.data])
            user=curr.fetchone()
            if user and user[4]==form.password.data:
                session['current_user']=user
                session['cart']={}
                flash('You have been logged in!','success')
                return  redirect(url_for('home'))
            else:
                flash('Login Unsuccessful. Please check email and password','danger')
                return  redirect(url_for('home'))    
    return render_template('login.html',title='Login',form=form,current_user=session.get('current_user'))


@app.route("/logout")
def logout():
    session['current_user']=None
    flash('You have been logged out!','success')
    return redirect(url_for('home'))

@app.route("/register",methods=['GET','POST'])
def register():
    conn=get_db_connection()
    curr=conn.cursor()
    if session.get('current_user'):
        return redirect(url_for('home'))
    form=RegistrationForm()
    if form.validate_on_submit():
        curr.execute("SELECT * FROM users WHERE email=%s",[form.email.data])
        user=curr.fetchone()
        if user:
            flash('Email already exitsts.','danger')
            return  redirect(url_for('register'))
        else:
            curr.execute(" INSERT INTO users(id,first_name,last_name,email,password) VALUES((select max(id) from users) + 1,%s,%s,%s,%s)",[form.first_name.data,form.last_name.data,form.email.data,form.password.data])
            conn.commit()
            flash(f'Account created for {form.first_name.data}! Please login below.','success')
            return redirect(url_for('login'))
    return render_template('register.html',title='Register',form=form,current_user=session.get('current_user'))
    
@app.route("/account",methods=['GET','POST'])
def account(): 
    if not session.get('current_user'):
        return redirect(url_for('login'))
    conn=get_db_connection()
    curr=conn.cursor()
    form=UpdateAccountForm()
    if form.validate_on_submit():
        curr.execute("SELECT * FROM users WHERE email=%s",[form.email.data])
        user=curr.fetchone()
        
        if user and user[0]!=session.get('current_user')[0]:
            flash('Email already in use','danger')
            return redirect(url_for('account'))
        else:
            curr.execute(" UPDATE users SET first_name=%s,last_name=%s,email=%s WHERE id=%s ",[form.first_name.data,form.last_name.data,form.email.data,session.get('current_user')[0]])
            conn.commit()
            temp=list(session.get('current_user'))
            temp[1]=form.first_name.data
            temp[2]=form.last_name.data
            temp[3]=form.email.data
            temp[7]=form.street_address.data
            temp[5]=form.age.data
            session['current_user']=tuple(temp)
            flash('Your account has been updated!','success')
            return redirect(url_for('account'))
    elif request.method=='GET':
        form.first_name.data=session.get('current_user')[1]
        form.last_name.data=session.get('current_user')[2]
        form.email.data=session.get('current_user')[3]
        form.street_address.data=session.get('current_user')[7]
        form.age.data=session.get('current_user')[5]
    return render_template('account.html',title='Account',form=form,current_user=session.get('current_user'))



@app.route('/checkout',methods=['GET','POST'])
def checkout():
    if not session.get('current_user'):
        flash('Please login to continue','danger')
        return redirect(url_for('login'))
    if request.method=='POST':
        print('method post')
        id=request.form.get('id')
        print(id)
        add=request.form.get('add')
        print(add)
        remove=request.form.get('remove')
        print(remove)
        if(request.form.get('add')):
            session['cart'][id]+=1
        elif(request.form.get('remove')):
            session['cart'][id]-=1
            if(session['cart'][id]==0):
                del session['cart'][id]
        elif(request.form.get('delete')):
            del session['cart'][id]
        return redirect(url_for('checkout'))
    if len(session.get('cart'))==0:
        flash('Your cart is empty','danger')
        return redirect(url_for('home'))
    
    conn=get_db_connection()
    curr=conn.cursor()
    products=[]
    total_cost=0
    for item in session.get('cart'):
        curr.execute("select * from products where id="+str(item))
        product=curr.fetchone()
        products.append((product,session['cart'][item]))
        if product:
            total_cost+=product[5]*session['cart'][item]
    return render_template('checkout.html',title='Checkout',products=products,total_cost=total_cost,current_user=session.get('current_user'))

@app.route('/buyall')
def buyall():
    if not session.get('current_user'):
        flash('Please login to continue','danger')
        return redirect(url_for('login'))
    conn=get_db_connection()
    curr=conn.cursor()
    flag=False
    num_of_items=0
    for key in session['cart']:
        curr.execute("select stock from products where id="+str(key))
        ret=curr.fetchone()
        if(ret[0]<session['cart'][key]):
            flag=True
            session['cart'][key]=ret[0]
        num_of_items=num_of_items+session['cart'][key]
    
    if flag :
        flash('Some order_items are more than stock','danger')
        return redirect(url_for('checkout'))

    curr.execute("select max(id) from order_items")
    max_order_items_id = curr.fetchone()
    curr.execute("select max(order_id) from orders")
    max_order_id = curr.fetchone()
    curr.execute(" INSERT into orders (order_id, user_id, status, created_at, num_of_item) values ("+str(max_order_id[0])+"+1, "+str(session['current_user'][0])+", 'Processing', current_date, "+str(num_of_items)+")")
    for key in session['cart']:
        curr.execute(" update products set stock=stock-"+str(session['cart'][key])+" where id="+str(key))
    
    curr.execute(" insert into order_items (id, order_id, inventory_item_id, status, created_at, sale_price) select "+str(max_order_items_id[0])+"+row_number() over (order by id), "+str(max_order_id[0])+"+1, id, 'Processing', current_date, cost from inventory_items where product_id="+str(key)+" and sold_at is null limit "+str(session['cart'][key]))
    curr.execute(" update inventory_items set sold_at=current_date from (select id from inventory_items where product_id="+str(key)+" and sold_at is null limit "+str(session['cart'][key])+") as t where t.id=inventory_items.id ")
    conn.commit()
    flash('Your order has been placed successfully!','success')
    session['cart'].clear()
    session['cart']={}
    return redirect(url_for('orders'))


@app.route("/orders")
def orders():
    if not session.get('current_user'):
        flash('Please login to continue','danger')
        return redirect(url_for('login'))
    conn=get_db_connection()
    curr=conn.cursor()
    curr.execute("select order_id, status, created_at , returned_at, shipped_at, delivered_at, case when status='Complete' then case when delivered_at::date + 10>current_date then true else false end else null end, num_of_item from orders where user_id=%s ORDER BY created_at",[session['current_user'][0]])
    orders=curr.fetchall()
    return render_template('orders.html',title='orders',orders=orders,current_user=session.get('current_user'))

@app.route("/cancel/orderid:<orderid>")
def cancel(orderid=None):
    conn=get_db_connection()
    curr=conn.cursor()
    curr.execute(" update orders set status='Cancelled', returned_at=current_date where order_id="+str(orderid)+" and (status= 'Processing' or status = 'Shipped')")
    conn.commit()
    curr.execute(" update order_items set status='Cancelled', returned_at=current_date where order_id="+str(orderid)+" and (status= 'Processing' or status = 'Shipped')")
    conn.commit()
    curr.execute("select inventory_item_id from order_items where order_id="+str(orderid))
    lis=curr.fetchall()
    for li in lis:
        curr.execute(" update inventory_items set sold_at=null where id="+str(li[0]))
        conn.commit()
        curr.execute(" select product_id from inventory_items where inventory_items.id="+str(li[0]))
        pid=curr.fetchone()
        curr.execute(" update products set stock=stock+1 where id="+str(pid[0]))
        conn.commit()
    flash('Your order has been cancelled successfully','success')
    return redirect(url_for('orders'))

@app.route("/returns/orderid:<orderid>")
def returns(orderid=None):
    conn=get_db_connection()
    curr=conn.cursor()
    curr.execute(" update orders set status='Returned', returned_at=current_date where order_id="+str(orderid)+" and (status= 'Complete')")
    conn.commit()
    curr.execute(" update order_items set status='Returned', returned_at=current_date where order_id="+str(orderid)+" and (status= 'Complete')")
    conn.commit()
    curr.execute("select inventory_item_id from order_items where order_id="+str(orderid))
    lis=curr.fetchall()
    for li in lis:
        curr.execute(" update inventory_items set sold_at=null where id="+str(li[0]))
        conn.commit()
        curr.execute("select product_id from inventory_items where inventory_items.id="+str(li[0]))
        pid=curr.fetchone()
        curr.execute(" update products set stock=stock+1 where id="+str(pid[0]))
        conn.commit()
    flash('Your order has been returned successfully','success')
    return redirect(url_for('orders'))




    
