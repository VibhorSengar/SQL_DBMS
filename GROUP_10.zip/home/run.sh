#!/bin/bash

# Navigate to the directory where the Flask app is located
cd ./FRONT_END

# Set the environment variables
export FLASK_APP=run.py
export FLASK_ENV=development
export FLASK_RUN_PORT=5010
export FLASK_RUN_HOST=127.0.0.1

# Run the Flask app
python3 -m flask run