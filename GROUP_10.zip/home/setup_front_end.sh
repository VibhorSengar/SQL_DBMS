pip3 install Flask

# Install other dependencies as needed
pip3 install Flask_Session
pip3 install Flask_WTF
pip3 install psycopg2-binary
pip3 install WTForms
pip3 instakk email_validator
pip3 install flask_paginate